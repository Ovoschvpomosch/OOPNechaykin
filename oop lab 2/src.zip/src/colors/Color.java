package colors;

public enum Color {
    TRANSPARENT,
    RED,
    GREEN,
    BLUE,
    PURPLE,
    WHITE,
    BLACK,
    YELLOW,
    BROWN
}
