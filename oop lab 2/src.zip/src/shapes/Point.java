package shapes;

import java.awt.*;

public abstract class Point extends Shape{
    private String name;
    private double area=0.0, perimeter=0.0;
    private double x=0.0;
    public double getX() {
        return x;
    }
    public void setX(Double  x) {
        this.x = x;
    }
    private double y=0.0;
    public double getY() {
        return y;
    }
    public void setY(Double  y) {
        this.y = y;
    }
    public double getArea() { return 0;}
    public double getPerimeter() {return 0;}
    public Point() {}

    public Point(String name, Color color, double area, double perimeter, double x, double y) {
        this.name = name;
        this.color = color;
        this.area = area;
        this.perimeter = perimeter;
        this.x = x;
        this.y = y;
}
    public void draw() {
        System.out.println("Фигура: " + getShapeName());
        System.out.println("Цвет: " + getColor());
        System.out.println("Площадь: " + getArea());
        System.out.println("Периметр: " + getPerimeter());
        System.out.println("Координаты точек: " + getCoordinates());
    }
}
