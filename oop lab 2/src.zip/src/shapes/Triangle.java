package shapes;
import java.awt.*;
public class Triangle extends Shape{
    private class Point {
        double x;
        double y;
    }
    Point a =  new Point();
    Point b =  new Point();
    Point c =  new Point();
    public Triangle.Point getA() {
        return a;
    }
    public void setA(Triangle.Point a) {
        this.a = a;
    }
    public Triangle.Point getB() {
        return b;
    }
    public void setB(Triangle.Point b) {
        this.b = b;
    }
    public Triangle.Point getC() {
        return c;
    }
    public void setC(Triangle.Point c) {
        this.c = c;
    }

    private void validate(Triangle.Point a, Triangle.Point b, Triangle.Point.c)
    {
        if (((a.x==b.x) && (b.x==c.x)) || ((a.y==c.y) && (b.y==c.y)) || (a.y==c.y))
            System.out.print("Точки а или б или с лежат на одной прямой");
    }
}
