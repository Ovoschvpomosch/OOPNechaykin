package shapes;

import java.awt.*;

public abstract class Circle extends Shape{
    private String name;
    private double area, perimeter;
    private Point point;
    private double radius;
    public Point getPoint() {
        return point;
    }
    public void setPoint(Point  point) {
        this.point = point;
    }
    public double getRadius() {
        return radius;
    }
    public void setRadius(Double  radius) {
        this.radius = radius;
    }
    public double getPerimeter() {return 2*3.1415926535*radius;}
    public double getArea() {return 3.1415926535*radius*radius;}
    private void validate(double radius){
        if (radius < 0)
            System.out.print("Радиус меньше нуля");
    }
    public Circle() {}

    public Circle(String name, Color color, double area, double perimeter, double radius, Point point) {
        this.name = name;
        this.color = color;
        this.area = area;
        this.perimeter = perimeter;
        this.radius = radius;
        this.point = point;
    }
    public void draw() {
        System.out.println("Фигура: " + getShapeName());
        System.out.println("Цвет: " + getColor());
        System.out.println("Площадь: " + getArea());
        System.out.println("Периметр: " + getPerimeter());
        System.out.println("Координаты точки " + getPoint());
    }
}
