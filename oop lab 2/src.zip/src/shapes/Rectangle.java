package shapes;

import java.awt.*;

public abstract class Rectangle extends Shape {
    private double perimeter, area;
    private String name;
    private class Point {
        double x;
        double y;
    }
    Point ab = new Point();
    Point cd = new Point();
    public Point getAB() {
        return ab;
    }
    public void setAB(Point  ab) {
        this.ab = ab;
    }
    public Point getCD() {
        return cd;
    }
    public void setCD(Point  cd) {
        this.cd = cd;
    }
    private void validate(Point ab, Point cd)
    {
        if ((ab.x==cd.x) || (ab.y==cd.y))
            System.out.print("Точки x или y лежат на одной прямой");
    }
    public double getPerimeter() {
        return 2*(Math.pow(2,(cd.x-ab.x)))+2*(Math.pow(2,(ab.y-cd.y)));
    }
    public double getArea() {
        return (Math.pow(2,(cd.x-ab.x)))*(Math.pow(2,(ab.y-cd.y)));
    }


    public Rectangle() {}

    public Rectangle(String name, Color color, double area, double perimeter, Point ab, Point cd) {
        this.name = name;
        this.color = color;
        this.area = area;
        this.perimeter = perimeter;
        this.ab = ab;
        this.cd = cd;
    }
    public void draw() {
        System.out.println("Фигура: " + getShapeName());
        System.out.println("Цвет: " + getColor());
        System.out.println("Площадь: " + getArea());
        System.out.println("Периметр: " + getPerimeter());
        System.out.println("Координаты точек: " + getCoordinates());
    }
}
